######################################################
#       Code du projet de series temporelles         #
######################################################
user="Albane" #Parmis "Thomas" et "Albane"

#Package utiles ####
require(zoo)
require(tseries)
require(fUnitRoots)

############################
#PARTIE 1 : Les donn�es ####
############################

#1. S�rie choisie : secteur, p�rim�tre, traitements �ventuels, transformation logarithmique,etc #### 

##a.Chargement des donn�es ####
if (user=="Albane"){setwd("C:/Users/Albane/Desktop/Semestre 2/S�ries temporelles lin�aires/Projet")}
if (user=="Thomas"){setwd("C:/Users/Thomas JACQUOT/Desktop/Semestre 2/S�ries temporelles/Projet/Code")}
datafile <- "locomotives.csv"
data <- read.csv(datafile, sep=";", skip = 2)[,1:2]
colnames(data)[1]="dates"

##b.S�rie en niveau et s�rie diff�renci�e ####
dates_char <- as.character(data$dates)
dates <- as.yearmon(seq(from=1990, to=2020+1/12, by=1/12)) 
locom <- zoo(data$X, order.by=dates)
dlocom <- diff(locom,1)
plot(cbind(locom,dlocom), main="Repr�sentation de la s�rie en niveau et de la s�rie diff�renci�e")
#La s�rie semble �tre I(1) car la s�rie en niveau pr�sente une tendance.
#La s�rie diff�renci�e semble stable autour de 0.25 et � peu pr�s stationnaire

##c.S�rie corrig�e de sa tendance et serie corig�e de sa tendance diff�renci�e ####
#On regarde si en enlevant la tendance les r�sultats sont meilleurs 
obs<-1:length((dates_char))
lm<-lm(data$X ~ obs)
summary(lm)  #La tendance et l'intercept sont significatifs
#On enl�ve la tendance 
X_notrend <- data$X - lm$coefficients[1] - lm$coefficients[2]*obs 
locom_notrend <- zoo(X_notrend, order.by=dates)
plot(cbind(locom,locom_notrend),main="Repr�sentation de la s�rie initiale et de la s�rie corrig�e de sa tendance")
#On compare la s�rie corrig�e de sa tendance et la s�rie diff�renci�e pour s�lectionner le melleur r�sultat de stationnarit�e
plot(cbind(locom_notrend,dlocom),main="Repr�sentation de la s�rie corrig�e de sa tendance et de la s�rie diff�renci�e")
#Enlever la tendance ne semble pas stationnariser la s�rie autant que la diff�rentiation le fait 

##d.Transformation logarithmique de la s�rie et diff�renciation de la s�rie en log ####
#On regarde si le passage au log permet d'avoir des r�sultats plus stationnaires 
dloglocom <- diff(log(locom),1)
plot(cbind(log(locom),dloglocom), main="Reprensatation de la serie en log et de la s�rie en log diff�renci�e")
#Le passage au log ne semble pas utile ici.

##e.S�rie selection�e ####
#Nous conservons donc la forme diff�rencic�e pour effectuer notre analyse 

#2. Stationnarit� ####

##a. Test de Dickey Fuller ####
#On v�rifie d'abord que la s�rie en niveau n'est pas stationnaire.
#La tendance est significative, on se placera donc dans un cas du test avec constante et tendance non nulles
adf <- adfTest(locom, lag=0, type="ct") #test ADF avec constante et tendance
adf
#il faut d'abord v�rifier la validit� du test, c�d l'absence d'autocorr�lation des r�sidus
Qtests <- function(series, k, fitdf=0) {
  pvals <- apply(matrix(1:k), 1, FUN=function(l) {
    pval <- if (l<=fitdf) NA else Box.test(series, lag=l, type="Ljung-Box", fitdf=fitdf)$p.value
    return(c("lag"=l,"pval"=pval))
  })
  return(t(pvals))
}

Qtests(adf@test$lm$residuals, 24, fitdf = length(adf@test$lm$coefficients))
# L'absence d'autocorr�lation des r�sidus est rejet�e (pour tous les lags), les r�sidus sont donc
# autocorr�l�s et le test non valide
adfTest_valid <- function(series, kmax, adftype){
  k <- 0
  noautocorr <- 0
  while (noautocorr==0){
    cat(paste0("ADF with ",k," lags: residuals OK? "))
    adf <- adfTest(series, lags=k, type=adftype)
    pvals <- Qtests(adf@test$lm$residuals, 24, fitdf = length(adf@test$lm$coefficients))[,2]
    if (sum(pvals<0.05,na.rm=T)==0) {
      noautocorr <- 1; cat("OK \n")
    } else cat("nope \n")
    k <- k+1
  }
  return(adf)
}
adf <- adfTest_valid(locom,24,adftype="ct")
#8 retards ont d� �tre ajout�s pour supprimer l'autocorr�lation des r�sidus, v�rifions
Qtests(adf@test$lm$residuals, 24, fitdf = length(adf@test$lm$coefficients))
#ok
adf
#la racine unitaire n'est pas rejet�e � 95%, la s�rie est donc int�gr�e au moins d'ordre 1


#testons donc la racine unitaire pour la s�rie diff�renci�e
summary(lm(dlocom ~ dates[-1]))
#Ni la constante ni la tendance ne sont significatives. 
#On est donc dans le cas du test ADF sans constante ni tendance.
adf <- adfTest_valid(dlocom,24,"nc")
Qtests(adf@test$lm$residuals, 24, fitdf = length(adf@test$lm$coefficients))
adf
#la racine unitaire est rejet�e au seuil de 95%. La s�rie diff�renci�e est donc I(0).
#locom est donc I(1).

##b. Test Philippe-Peron ####
pp.test(dlocom)
#le test de Philippe Peron semble indiquer (lui aussi) que s�rie diff�renci�e est stationnaire
#Autrement dit la s�rie est int�gr�e d'ordre 1 ie I(1)

#3.Repr�sentation de la s�rie choisie avant et apr�s transformation ####
#La comparaison avant/apr�s est la suivante : 
plot(cbind(locom,dlocom), main="Repr�sentation de la s�rie choisie avant et apr�s transformation")

#############################
#PARTIE 2 : Mod�les ARMA ####
#############################

#1.Choix d'un mod�le ARMA
##a.Identification des param�tres ####
#On regarde les ordres max des AR et MA
par(mfrow=c(1,2))
pacf(dlocom,24);acf(dlocom,24) #on regarde jusqu'� deux ans de retard
#la PACF(4) est la PACF significative d'ordre le plus �lev� (hormis 14), on prend donc p*=4
#l'ACF(3) est l'ACF significative d'ordre le plus �lev� en dessous de 6, on prend donc q*=3
pmax=4;qmax=3

##b. Selection des mod�les admissibles ####
mat <- matrix(NA,nrow=pmax+1,ncol=qmax+1) #matrice vide � remplir
rownames(mat) <- paste0("p=",0:pmax) #renomme les lignes
colnames(mat) <- paste0("q=",0:qmax) #renomme les colonnes
AICs <- mat #matrice des AIC non remplie
BICs <- mat #matrice des BIC non remplie
pqs <- expand.grid(0:pmax,0:qmax) #toutes les combinaisons possibles de p et q
for (row in 1:dim(pqs)[1]){ #boucle pour chaque (p,q)
  p <- pqs[row,1] #r�ecup`ere p
  q <- pqs[row,2] #r�ecup`ere q
  estim <- try(arima(dlocom,c(p,0,q),include.mean = F)) #tente d'estimer l'ARIMA
  AICs[p+1,q+1] <- if (class(estim)=="try-error") NA else estim$aic #assigne l'AIC
  BICs[p+1,q+1] <- if (class(estim)=="try-error") NA else BIC(estim) #assigne le BIC
}

AICs
BICs

AICs==min(AICs)
BICs==min(BICs)
#l'ARIMA(3,1,3) minimise l'AIC
arima313 <- arima(locom,c(3,1,3),include.mean=F)
#l'ARIMA(1,1,1) minimise le BIC 
arima111 <- arima(locom,c(1,1,1),include.mean=F)

##c. Ajustement et validation des mod�les ####
arima313
arima111
#A chaque fois tous les coefficients sont significatifs (le rapport du coefficient sur
#son �cart type est toujours strictement sup�rieur � 1.96 en valeur absolue)
#Les deux mod�les sont donc bien ajust�s 
Qtests(arima313$residuals,24,fitdf=6)
#Ce mod�le n'est pas valide. L'absence d'auto-corr�lation est rejet�e pour certains lag 
Qtests(arima111$residuals,24,fitdf=2)
#Ce mod�le n'est pas valide. L'absence d'auto-corr�lation est rejet�e pour certains lag

#On regarde un par un les mod�les qui minimisent l'AIC et on v�rifie leur validit�
AICs_croissant=order(AICs)
for (i in AICs_croissant){ #On boucle sur le mod�le ayant l'AIC du plus faible au plus grand
  if(i%%5==0){p=4} else p=i%%5-1 #On r�cup�re le coefficient de p
  q=(i-1)%/%5 #On r�cup�re le coefficient de q
  arima_i=arima(locom,c(p,1,q),include.mean=F)
  pvals <- Qtests(arima_i$residuals, 24, fitdf = p+q)[,2]
  if (sum(pvals<0.05,na.rm=T)==0) {
    noautocorr <- 1; cat("Le mod�le arima(",p,",1,",q,") est valide \n",sep="")
    break
  } else cat("Le mod�le arima(",p,",1,",q,") n'est pas valide \n",sep="")
}
#Le mod�le valide qui minimise le AIC est donc l'arima(4,1,0).

#On regarde un par un les mod�les qui minimisent le BIC et on v�rifie leur validit�
BICs_croissant=order(BICs)
for (i in BICs_croissant){ #On boucle sur le mod�le ayant le BIC du plus faible au plus grand
  if(i%%5==0){p=4} else p=i%%5-1 #On r�cup�re le coefficient de p
  q=(i-1)%/%5 #On r�cup�re le coefficient de q
  arima_i=arima(locom,c(p,1,q),include.mean=F)
  pvals <- Qtests(arima_i$residuals, 24, fitdf = p+q)[,2]
  if (sum(pvals<0.05,na.rm=T)==0) {
    noautocorr <- 1; cat("Le mod�le arima(",p,",1,",q,") est valide \n",sep="")
    break
  } else cat("Le mod�le arima(",p,",1,",q,") n'est pas valide \n",sep="")
}
#Le mod�le valide qui minimise le BIC est donc l'arima(4,1,0). 

#Le meilleur mod�le valide selon le crit�re AIC et selon le BIC co�ncide donc.
#Il s'agit de l'arima(4,1,0) 
arima410=arima(locom,c(4,1,0),include.mean = FALSE)
arima410
#Ce mod�le est bien ajust� car le coefficient AR de degr� le plus �l�v� est significatif. 
#Nous retenons donc le mod�le arima(4,1,0). 


#2. Mod�le ARIMA retenu
#Comme nous venons de le voir, on retient le arima(4,1,0)
#Par curiosit�, on peut regarder comparer son R carr� ajust� 
#avec ceux des arima313 et arima111
adj_r2 <- function(model){
  p <- model$arma[1]
  q <- model$arma[2]
  n <- model$nobs-max(p,q)
  ss_res <- sum(model$residuals^2)
  ss_tot <- sum(dlocom[-c(1:max(p,q))]^2)
  adj_r2 <- 1-(ss_res/(n-p-q-1))/(ss_tot/(n-1))
  return(adj_r2)
}
adj_r2(arima410)
adj_r2(arima111)
adj_r2(arima313)

##########################
#PARTIE 3 : Pr�vision ####
##########################

#Question 1 ####
#On suppose que le terme d'erreur suit une loi gaussienne(0,\sigma^2)
#Il faut donc estimer \sigma^2 :
sigma2=arima410$sigma2

#Question 2 ####
#voir rapport

#Question 3 ####
#On doit repr�senter la r�gion de confiance
T=length(locom)
Tmoins1=length(dlocom)
locom_num=as.numeric(locom) #On convertit de "double" � "numeric"
dlocom_num=as.numeric(dlocom)
coefs=as.numeric(arima410$coef)
#On calcule la pr�vision de X_T+1 donn� par notre mod�le ARIMA410
X_Tplus1=locom_num[T]+coefs[1]*dlocom_num[T-1]+coefs[2]*dlocom_num[T-2]+
  coefs[3]*dlocom_num[T-3]+coefs[4]*dlocom_num[T-4] 
  #Il y a un d�calage d'incr�mentation entre locom et dlocom
X_Tplus1


#Sous les hypoth�ses de r�sidus gaussiens, cette valeur suit une loi normale N(X_T+1,\sigma^2)
alpha=0.05
#On calcule les bornes inf et sup de r�gion de confiance 1-alpha 
X_Tplus1_low=X_Tplus1-sqrt(sigma2)*qnorm(1-alpha/2)
X_Tplus1_low
X_Tplus1_up=X_Tplus1+sqrt(sigma2)*qnorm(1-alpha/2)
X_Tplus1_up

#On calcule la pr�vision de X_T+2 donn� par notre mod�le ARIMA410
X_Tplus2=X_Tplus1+coefs[1]*(X_Tplus1-locom_num[T])+coefs[2]*dlocom_num[T-1]+
  coefs[3]*dlocom_num[T-2]+coefs[4]*dlocom_num[T-3] 
X_Tplus2
#Sous les hypoth�ses de r�sidus gaussiens, cette valeur suit une loi normale N(X_T+2,(1+Phi1^2)*sigma^2)
#On calcule les bornes inf et sup de r�gion de confiance 1-alpha 
X_Tplus2_low=X_Tplus2-sqrt((1+coefs[1])^2*sigma2+sigma2)*qnorm(1-alpha/2)
X_Tplus2_low
X_Tplus2_up=X_Tplus2+sqrt((1+coefs[1])^2*sigma2+sigma2)*qnorm(1-alpha/2)
X_Tplus2_up

#Repr�sentation graphique de l'intervalle de confiance
dates_plus2 <- as.yearmon(seq(from=1990, to=2020+3/12, by=1/12)) 
locom_plus2=locom_num
locom_plus2[T+1]=X_Tplus1
locom_plus2[T+2]=X_Tplus2
par(mfrow=c(1,1))
#On repr�sente la s�rie avec les deux pr�visions
plot(dates_plus2,locom_plus2,type="lines")

#On fait un focus sur les ntail derniers mois et on affiche la r�gion de confiance � 95%
ntail=20
ylim=c(100,140)
xlim=c(tail(dates_plus2,ntail)[1],tail(dates_plus2,ntail)[ntail])
plot(tail(dates_plus2,ntail),tail(locom_plus2,ntail),type="lines",ylim=ylim,xlim=xlim,ylab=" ",xlab="P�riodes de sept 2018 � avril 2020")
par(new=TRUE)
plot(tail(dates_plus2,2),c(X_Tplus1_low,X_Tplus2_low),type="l",axes=FALSE,xlab=" ",ylab=" ",ylim=ylim,xlim=xlim)
par(new=TRUE)
plot(tail(dates_plus2,2),c(X_Tplus1_up,X_Tplus2_up),type="l",axes=FALSE,xlab=" ",ylab=" ",ylim=ylim,xlim=xlim)
x=c(tail(dates_plus2,2),tail(dates_plus2,1),tail(dates_plus2,2)[1])
y=c(X_Tplus1_low,X_Tplus2_low,X_Tplus2_up,X_Tplus1_up)
polygon(x,y, col="grey70", border="transparent")
points(tail(dates_plus2,2),c(X_Tplus1,X_Tplus2), col = "red", pch =3,xlab="",ylab="")

ntail=362
ylim=c(20,140)
xlim=c(tail(dates_plus2,ntail)[1],tail(dates_plus2,ntail)[ntail])
plot(tail(dates_plus2,ntail),tail(locom_plus2,ntail),type="lines",ylim=ylim,xlim=xlim,ylab=" ",xlab="P�riode de janvier 1990 � avril 2020")
par(new=TRUE)
plot(tail(dates_plus2,2),c(X_Tplus1_low,X_Tplus2_low),type="l",axes=FALSE,xlab=" ",ylab=" ",ylim=ylim,xlim=xlim)
par(new=TRUE)
plot(tail(dates_plus2,2),c(X_Tplus1_up,X_Tplus2_up),type="l",axes=FALSE,xlab=" ",ylab=" ",ylim=ylim,xlim=xlim)
x=c(tail(dates_plus2,2),tail(dates_plus2,1),tail(dates_plus2,2)[1])
y=c(X_Tplus1_low,X_Tplus2_low,X_Tplus2_up,X_Tplus1_up)
polygon(x,y, col="grey70", border="transparent")
points(tail(dates_plus2,2),c(X_Tplus1,X_Tplus2), col = "red", pch =3,xlab="",ylab="")

#####
#FIN#
#####